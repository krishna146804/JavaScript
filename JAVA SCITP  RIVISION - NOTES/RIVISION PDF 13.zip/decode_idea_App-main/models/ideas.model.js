module.exports = {

    1 : {
        id : 1,
        idea_name : "Great Idea",
        author_name : "Vishwa Mohan",
        idea_description : "This is one of the finest idea I ever had"
    },

    2 : {
        id : 2,
        idea_name : "Great Second Idea",
        author_name : "Prashant",
        idea_description : "This is one of the second most finest idea I ever had"
    },
    3 : {
        id : 3,
        idea_name : "Class idea",
        author_name : "Sunny",
        idea_description : "This idea came from the students of my batch "
    }

}